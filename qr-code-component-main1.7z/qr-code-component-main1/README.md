# Frontend Mentor - QR code component solution
![](./screenshot.png)

This is my solution to the [QR code component challenge on Frontend Mentor]